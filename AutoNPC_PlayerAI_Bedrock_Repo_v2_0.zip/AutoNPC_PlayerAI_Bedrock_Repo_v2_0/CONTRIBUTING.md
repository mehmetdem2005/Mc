# Katkı kuralları

- Her değişiklikte sürüm numarasını artır.
- Paket görünür adında sürüm yazsın: `AutoNPC PlayerAI vX.Y BP/RP`.
- Dosya adında sürüm yazsın: `AutoNPC_PlayerAI_vX_Y_AllInOne.mcaddon`.
- Behavior Pack ve Resource Pack identifier çakışmalarına dikkat et.
- Eski sürüm entity/item identifier kalıntısı bırakma.
